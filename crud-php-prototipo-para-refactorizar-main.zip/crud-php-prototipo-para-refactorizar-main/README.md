# crud-php-prototipo-para-refactorizar
Prototipo de CRUD para refactorizar
